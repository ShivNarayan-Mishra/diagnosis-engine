# Phase 2 delivery — corrected version

## What changed from the first version of this zip

The first version invented a replacement `generator.py` and guessed at
`interfaces.py`'s contents. That was wrong to do — should have asked for the real files
first. This version is rewritten against your actual `generator.py` and `interfaces.py`
(as you pasted them). **Your `generator.py` is untouched — this zip does not include or
modify it.** Everything here only calls its one real public method,
`generate(n, start_time=None, interval_seconds=1.0)`.

Before shipping this version, I built a throwaway local harness with your exact
`generator.py` and `interfaces.py` plus a fake in-memory store, and actually ran both
scenarios end-to-end (not just syntax-checked) — confirmed: before/after trace counts,
factor values forced correctly on each side of the injection point, failure rate visibly
higher on the faulted side, `injected_fault_id` set only on the after-window traces,
`GroundTruth` fields correct. That harness isn't part of this delivery — it was just to
catch a repeat of the same mistake before handing this to you again.

## Install — plain non-destructive merge, no special cases this time

```bash
cd ~/projects/diagnosis-engine
unzip -o ~/Downloads/phase2_diagnosis_engine.zip -d /tmp/phase2_unzipped
cp -rn /tmp/phase2_unzipped/src ./
cp -rn /tmp/phase2_unzipped/scripts ./
cp -rn /tmp/phase2_unzipped/tests ./
```

## What's in it

- `src/benchmark/scenarios/base.py` — `FaultScenario` ABC. Confirmed your real
  `interfaces.py` doesn't define this, so it lives here — see the docstring for how to
  relocate it later if you want strict adherence to the plan's folder layout.
- `src/benchmark/scenarios/tool_regression.py` — `ToolRegressionScenario`, partial
  rollout of `tool_version="2.4"` tied to elevated failure rate.
- `src/benchmark/scenarios/model_swap.py` — `ModelSwapScenario`, full cutover of
  `model_version` from `"v2"` (your generator's real baseline) to `"v3"`.
- `src/store/ground_truth_store.py` — `write_ground_truth()`, inserts into
  `fault_scenarios`.
- `scripts/seed_stable_traces.py` — calls your real `generate()` method correctly now
  (previous version called a `generate_batch` method that never existed).
- `scripts/run_scenario.py` — runs one scenario against the real DB, logs GroundTruth.
- `tests/benchmark/test_scenarios.py` — integration tests against the real Postgres.

## How to verify

```bash
source .venv/bin/activate
docker compose up -d

python scripts/seed_stable_traces.py --n 200
python scripts/run_scenario.py --scenario tool_regression
pytest tests/benchmark/test_scenarios.py -v
```

```sql
SELECT date_trunc('minute', timestamp), COUNT(*),
       SUM(CASE WHEN outcome='failure' THEN 1 ELSE 0 END) AS failures
FROM traces GROUP BY 1 ORDER BY 1;

SELECT * FROM fault_scenarios ORDER BY created_at DESC LIMIT 5;
```
